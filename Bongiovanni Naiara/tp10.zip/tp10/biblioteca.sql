-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-09-2025 a las 00:44:33
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `biblioteca`
--
CREATE DATABASE IF NOT EXISTS `biblioteca` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `biblioteca`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id_Comentario` int(11) NOT NULL,
  `id_Libro` int(11) NOT NULL,
  `id_Miembro` int(11) NOT NULL,
  `comentario` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id_Comentario`, `id_Libro`, `id_Miembro`, `comentario`) VALUES
(1, 3, 2, 'Muy buen libro, recomendado'),
(2, 2, 3, 'La historia me atrapó mucho'),
(3, 2, 3, 'No me gustó el final'),
(4, 4, 4, 'Excelente narrativa'),
(5, 4, 4, 'Personajes muy bien logrados'),
(6, 4, 4, 'Lo volvería a leer sin dudas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libro`
--

CREATE TABLE `libro` (
  `id_Libro` int(11) NOT NULL,
  `título` varchar(25) NOT NULL,
  `autor` varchar(25) NOT NULL,
  `género` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libro`
--

INSERT INTO `libro` (`id_Libro`, `título`, `autor`, `género`) VALUES
(1, 'El Señor de los anillos', 'J. R. R. Tolkien', 'Fantasía'),
(2, 'Harry Potter: la piedra f', 'J. K. Rowling', 'Fantasía'),
(3, 'La caída de la casa Usher', 'Edgar Allan Poe', 'Terror Literario'),
(4, 'Un amor de otra época', 'Adam West', 'Novela Rosa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `miembro`
--

CREATE TABLE `miembro` (
  `id_Miembro` int(11) NOT NULL,
  `nombre_apellido` varchar(25) NOT NULL,
  `dirección` varchar(25) NOT NULL,
  `teléfono` bigint(15) NOT NULL,
  `correo_electrónico` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `miembro`
--

INSERT INTO `miembro` (`id_Miembro`, `nombre_apellido`, `dirección`, `teléfono`, `correo_electrónico`) VALUES
(1, 'Bongiovanni Naiara', 'Av. Siempre Viva 742', 2664010378, 'pintamostodalacasa@gmail.'),
(2, 'Dupre Emanuel', 'Calle Falsa 123', 2665323245, 'dosdetrescaidas@gmail.com'),
(3, 'Fet Enzo', 'Las Catitas 104', 2665782933, 'soychicarebelde@gmail.com'),
(4, 'Bossa Jose', 'Fondo de bikini 124', 2665939394, 'pupitre15@@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `préstamo_libro`
--

CREATE TABLE `préstamo_libro` (
  `id_Préstamo` int(11) NOT NULL,
  `id_Libro` int(11) NOT NULL,
  `id_Miembro` int(11) NOT NULL,
  `fechaP` date NOT NULL,
  `fechaD` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `préstamo_libro`
--

INSERT INTO `préstamo_libro` (`id_Préstamo`, `id_Libro`, `id_Miembro`, `fechaP`, `fechaD`) VALUES
(1, 3, 2, '2025-09-19', NULL),
(2, 1, 1, '2025-09-21', NULL),
(3, 2, 3, '2025-09-20', '2025-09-23'),
(4, 4, 4, '2025-09-19', '2025-09-23');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id_Comentario`),
  ADD KEY `id_Libro` (`id_Libro`),
  ADD KEY `id_Miembro` (`id_Miembro`);

--
-- Indices de la tabla `libro`
--
ALTER TABLE `libro`
  ADD PRIMARY KEY (`id_Libro`);

--
-- Indices de la tabla `miembro`
--
ALTER TABLE `miembro`
  ADD PRIMARY KEY (`id_Miembro`);

--
-- Indices de la tabla `préstamo_libro`
--
ALTER TABLE `préstamo_libro`
  ADD PRIMARY KEY (`id_Préstamo`),
  ADD KEY `id_Libro` (`id_Libro`),
  ADD KEY `id_Miembro` (`id_Miembro`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id_Comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `libro`
--
ALTER TABLE `libro`
  MODIFY `id_Libro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `miembro`
--
ALTER TABLE `miembro`
  MODIFY `id_Miembro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `préstamo_libro`
--
ALTER TABLE `préstamo_libro`
  MODIFY `id_Préstamo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`id_Libro`) REFERENCES `libro` (`id_Libro`),
  ADD CONSTRAINT `comentarios_ibfk_2` FOREIGN KEY (`id_Miembro`) REFERENCES `miembro` (`id_Miembro`);

--
-- Filtros para la tabla `préstamo_libro`
--
ALTER TABLE `préstamo_libro`
  ADD CONSTRAINT `préstamo_libro_ibfk_1` FOREIGN KEY (`id_Libro`) REFERENCES `libro` (`id_Libro`),
  ADD CONSTRAINT `préstamo_libro_ibfk_2` FOREIGN KEY (`id_Miembro`) REFERENCES `miembro` (`id_Miembro`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
